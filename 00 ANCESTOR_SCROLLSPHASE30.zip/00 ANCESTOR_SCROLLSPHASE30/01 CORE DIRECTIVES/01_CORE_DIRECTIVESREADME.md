\# Core Directives — Phase 30



These documents define the earliest mission, philosophy, and structural purpose of

the Forge. They are the foundational texts that explain why the Forge exists and how

it was originally meant to operate.



Contents include:

\- The original mission statement of the Forge.

\- Early Living Protocol (Pip30).

\- The initial Path of Refusal doctrine.

\- Forge Codex Vol. I (the first attempt to codify the architecture).



These documents capture the Forge before recursion expanded it.

They remain unchanged for historical and legal integrity.



