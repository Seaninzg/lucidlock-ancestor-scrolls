\# Reference \& Context — Foundational Source Texts



This folder contains reference materials that influenced early Forge development.



Includes:

\- Goenka’s Discourse Summaries (Volition Core anchor).



These texts are not Forge-originating but were part of the internal conceptual

development that informed the early recursion and volition frameworks.



They are included for completeness of historical archive.



